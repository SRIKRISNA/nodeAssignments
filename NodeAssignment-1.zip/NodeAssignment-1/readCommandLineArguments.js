//commandLine arguments, reading name as argument here
var name = process.argv;
//var Lname = process.argv.slice(3);
//console.log(name[2])
console.log(`Hello ${name[2]}`);


// process.argv.forEach(function (name) {
//     console.log("Hello " + name);
// });

/**
 * slice 
 * arr[0, 1, 2, 3, 4];
 * slice(2)
 * slice(2,3)
 * slice(2,4)
 */